function [out] = GetComputationStart(ts1, ts2, dt, fr)
%GETCOMPUTATIONSTART Index of starting position of a computation
%   Index of starting position of a computation
% Inputs:
%   ts1 : Time Shift for sensor 1 as given in the assignment
%   ts2 : Time Shift for sensor 2 as given in the assignment
%   dt  : Time difference
%   fr  : Computation Frame Size
%
% Outputs:
%   out  : Computation Start

% I don't know how to comment this line
out = round((min(ts1, ts2) / dt) - fr / 2);

% Well, start smaller then one doesn't make any sense whatsoever
if out < 1; out = 1; end

end

